<?php
define('IN_ECTOUCH', true);
error_reporting(0);
$wxch_lang['copyright'] = 'Copyright &copy; 2015 微信公众平台';
$wxch_lang['cp_home'] = 'O菜龙工作室管理中心';
$wxch_lang['kefu'] = '';
$wxch_lang['config'] = '微信通设置';
?>